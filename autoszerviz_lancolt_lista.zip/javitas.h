#ifndef JAVITAS_H_INCLUDED
#define JAVITAS_H_INCLUDED

Javitasok* javitas_felvetele_listaba(Javitasok* eleje, Javitas uj_javitas);

void JavitasHozzaadasa(Bejegyzes* szerviz);

void JavitasokListazasa(Bejegyzes* szerviz);

void JavitasFelszabaditas(Javitasok* szerviztortenet);

#endif // JAVITAS_H_INCLUDED
